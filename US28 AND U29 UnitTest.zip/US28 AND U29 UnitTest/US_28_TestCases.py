#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 15:30:19 2017

@author: Harish7KJ
"""

import unittest
from datetime import datetime
import csv     
def list_decreasing_children_PassFile():
     with open('US28_Pass1.csv','r+') as fp1:
         ret = False
         i = 1 
         for line in fp1.readlines():
             lineS = line.split(',')
             children = lineS[7].split()
             if len(children)==0 or len(children)==1:
                 ret = True
             i+=1
     return ret
def list_decreasing_children_FailFile():
    with open('US28_Fail1.csv','r+') as fp1:
        ret = True
        i = 1 
        for line in fp1.readlines():
            if i == 1:
                i += 1
                continue
            lineS = line.split(',')
            children = lineS[7].split()
            if len(children)==0 or len(children)==1:
                ret = False
                print "ERROR: FAMILY: US28: Family ",lineS[0],"has zero or one child"
            i+=1
    return ret
class TestCase(unittest.TestCase):
    def test_decreasing_children(self):
        self.assertTrue(list_decreasing_children_PassFile())
        self.assertFalse(list_decreasing_children_FailFile())
        

if __name__ == "__main__":   
    unittest.main()