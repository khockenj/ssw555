#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 17:18:55 2017

@author: Harish7KJ
"""

import unittest
from datetime import datetime
import csv     

def list_deceased_individuals_PassFile():
     with open('US29_Pass.csv','r+') as fp1:
        ret = True
        for line in fp1.readlines():
            lineS = line.split(',')
            if lineS[4] == 'Alive':
                print "ERROR: INDIVIDUAL: US30: Individual",lineS[0]," is not deceased"
                ret = False
     return ret

def list_deceased_individuals_FailFile():
     with open('US29_Fail.csv','r+') as fp1:
        ret = True
        for line in fp1.readlines():
            lineS = line.split(',')
            if lineS[4] == 'Alive':
                print "ERROR: INDIVIDUAL: US30: Individual",lineS[0]," is not deceased"
                ret = False
     return ret

class TestCase(unittest.TestCase):
    def test_list_deceased_individuals(self):
        self.assertTrue(list_deceased_individuals_PassFile())
        self.assertFalse(list_deceased_individuals_FailFile())
        

if __name__ == "__main__":   
    unittest.main()