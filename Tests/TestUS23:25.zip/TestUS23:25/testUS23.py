import unittest


def US23_pass():

    i = open("indipass.csv", "r")
    iString = i.read()

    ilist = []
    for line in iString.split("\n"):
        ilist.append(line.split(","))

    del ilist[0]

    flag = 0

    for i in range(len(ilist) - 2):
        j = i+1
        if (ilist[i][1] == ilist[j][1]) & (ilist[j][3] == ilist[j][3]):
            print('ERROR: INDIVIDUAL: US23: ' + ilist[i][0] + 'and' + ilist[j][0] + 'have same name and date of birth')
            flag = 1

    if flag == 1:
        return False
    else:
        return True

def US23_fail():
    i = open("indifail.csv", "r")
    iString = i.read()

    ilist = []
    for line in iString.split("\n"):
        ilist.append(line.split(","))

    del ilist[0]

    flag = 0

    for i in range(len(ilist) - 2):
        j = i + 1
        if (ilist[i][1] == ilist[j][1]) & (ilist[j][3] == ilist[j][3]):
            print('ERROR: INDIVIDUAL: US23: ' + ilist[i][0] + 'and' + ilist[j][0] + 'have same name and date of birth')
            flag = 1

    if flag == 1:
        return False
    else:
        return True

class TestCase(unittest.TestCase):
    def test_decreasing_children(self):
        self.assertTrue(US23_pass())
        self.assertFalse(US23_fail())


if __name__ == "__main__":
    unittest.main()
