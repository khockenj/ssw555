import unittest
from datetime import datetime, timedelta
import csv


def multiple_siblings_pass():
    i = open("indipass.csv", "r")
    iString = i.read()

    ret = True
    ilist = []
    for line in iString.split("\n"):
        ilist.append(line.split(","))
    count = 1
    people = []
    del ilist[0]
    for i in range(len(ilist) - 2):
        if (ilist[i][3] == ilist[i + 1][3]) & (ilist[i][6] == ilist[i + 1][6]):
            count += 1
            people.append('{}'.format(ilist[i][0]))

    if count > 5:
        ret = True

    return ret


def multiple_siblings_fail():
    i = open("indifail.csv", "r")
    iString = i.read()


    ret = False
    ilist = []
    for line in iString.split("\n"):
        ilist.append(line.split(","))
    count = 1
    people = []
    del ilist[0]
    for i in range(len(ilist) - 2):
        if (ilist[i][3] == ilist[i + 1][3]) & (ilist[i][6] == ilist[i + 1][6]):
            count += 1
            people.append('{}'.format(ilist[i][0]))

    if count > 5:
        ret = False

    return ret

class TestCase(unittest.TestCase):
    def test_decreasing_children(self):
        self.assertTrue(multiple_siblings_pass())
        self.assertFalse(multiple_siblings_fail())


if __name__ == "__main__":
    unittest.main()
