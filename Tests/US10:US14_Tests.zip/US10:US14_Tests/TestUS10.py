import unittest
from datetime import datetime, timedelta
import csv

def marriage_after_14_pass():
    f = open("familypass.csv", "r+")
    fString = f.read()

    flist = []
    for line in fString.split("\n"):
        flist.append(line.split(","))

    i = open("indipass.csv", "r+")
    iString = i.read()

    ilist = []
    for line in iString.split("\n"):
        ilist.append(line.split(","))

    rlist = []
    for i in range(len(flist) - 1):
        for j in range(len(ilist) - 1):
            if flist[i][3] == ilist[j][0]:
                rlist.append("{},{},{}".format(ilist[j][0], ilist[j][3], flist[i][1]))

            if flist[i][5] == ilist[j][0]:
                rlist.append("{},{},{}".format(ilist[j][0], ilist[j][3], flist[i][1]))
    tlist = []
    for i in rlist:
        for line in i.split("\n"):
            tlist.append(line.split(","))

    for k in tlist:
        if (k[2] != 'Years not provided') & (k[1] != 'Years not provided'):
            mday = (datetime.strptime(k[2], '%d %b %Y')).date()
            bday = datetime.strptime(k[1], '%d %b %Y').date()
            nbday = bday + timedelta(days=14 * 365)

            if mday < nbday:
                retur = True


    return True


def marriage_after_14_fail():
    f = open("familyfail.csv", "r+")
    fString = f.read()

    flist = []
    for line in fString.split("\n"):
        flist.append(line.split(","))

    i = open("indifail.csv", "r+")
    iString = i.read()

    ret = False

    ilist = []
    for line in iString.split("\n"):
        ilist.append(line.split(","))

    rlist = []
    for i in range(len(flist) - 1):
        for j in range(len(ilist) - 1):
            if flist[i][3] == ilist[j][0]:
                rlist.append("{},{},{}".format(ilist[j][0], ilist[j][3], flist[i][1]))

            if flist[i][5] == ilist[j][0]:
                rlist.append("{},{},{}".format(ilist[j][0], ilist[j][3], flist[i][1]))
    tlist = []
    for i in rlist:
        for line in i.split("\n"):
            tlist.append(line.split(","))

    for k in tlist:
        if (k[2] != 'Years not provided') & (k[1] != 'Years not provided'):
            mday = (datetime.strptime(k[2], '%d %b %Y')).date()
            bday = (datetime.strptime(k[1], '%d %b %Y')).date()
            nbday = bday + timedelta(days=14 * 365)

            if mday < nbday:
                ret = False

    return False


class TestCase(unittest.TestCase):
    def test_decreasing_children(self):
        self.assertTrue(marriage_after_14_pass())
        self.assertFalse(marriage_after_14_fail())


if __name__ == "__main__":
    unittest.main()
